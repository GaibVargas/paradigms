# Rodando o projeto
```
clisp -c solver.lisp
clisp solver.fas
```