# Rodando o programa
```
ghc main.hs solver.hs boards.hs types.hs
```

# Referências
Solução adaptada de:
http://www.cs.nott.ac.uk/~pszgmh/sudoku.lhs